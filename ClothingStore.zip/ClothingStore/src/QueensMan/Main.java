package QueensMan;
import java.util.*;

public class Main {
	Scanner scan = new Scanner (System.in);
	int input = -1;
	
	Vector <Clothes> clothesList = new Vector <Clothes>();
	
	public Main() {
		menu();
	}
	public void menu () {
		do {
			System.out.println("================================");
			System.out.println("            QueensMan          ");
			System.out.println("=================================");
			System.out.println("1. View Clothes");
			System.out.println("2. Add Clothes");
			System.out.println("3. Remove Clothes");
			System.out.println("4. exit");
			System.out.println(">>");
			try {
				input = scan.nextInt();
			}catch (Exception e) {
			}
			switch (input) {
			case 1:
				viewClothes();
				break;
			
			case 2:
				addClothes ();
				break;
			
			case 3:
				removeClothes ();
				break;
			
			case 4:
				System.out.println("THANK YOU");
				System.exit(0);
			
				break;
			}
	}while (input <1 || input >4);
	}

	private void removeClothes() {
		if(clothesList.isEmpty()) {
			System.out.println("There is no clothes...");
			scan.nextLine();
			menu();
			
		}
	}
	public void viewClothes() {
		if(clothesList.isEmpty()) {
			System.out.println("There is no clothes...");
			scan.nextLine();
			menu();
		}
		System.out.printf("| %-5s | %-15s | %-10s | %-10s | %-15s | %-15s | %-15s | \n" , "No.", "Material", "Type", "Size", "Color", "Completion Time", "Lapel Width");
		menu();
	}
	public void addClothes() {
		String size;
		String clothMaterial;
		String color;
		int lapelWidth;
		String clothType;
		
		do{
			System.out.println("Input cloth size [S | M | L]:");
			size = scan.nextLine();
					
		}while (!size.equals("S")&& !size.equals("M") && !size.equals("L"));
		
		do {
			System.out.println("Input cloth material [Cotton | Silk]:");
			clothMaterial = scan.nextLine();
		}while(!clothMaterial.equals("Cotton") && !clothMaterial.equals("Silk"));
		
		do {
			System.out.println("Input Color [5..13]:");
			color = scan.nextLine();	
		} while (color.length()<5 || color.length()>13);
		
		do {
			System.out.println("Input lapel width [2.25 - 4.50]:");
			lapelWidth = scan.nextInt();
		} while (lapelWidth < 2.25 || lapelWidth > 4.50);
		
		do {
			System.out.println("Input Cloth type [Dress | Suit]");
			clothType = scan.nextLine();
		} while (!clothType.equals("Dress")&& !clothType.equals("Suit"));
		
	
		System.out.println("Cloth successfully inserted.");
		System.out.println("press enter to continue");
		
		
		menu();
		}
		
		
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
