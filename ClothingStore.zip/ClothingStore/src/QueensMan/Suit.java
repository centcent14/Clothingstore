package QueensMan;

import java.util.Random;

public class Suit extends Clothes {
	Random rand = new Random();
	public Suit(int completionTime) {
		
		
	}
	public void additionalWorkingTime () {
		
		int additionalWorkingTime = rand.nextInt(10);
	}
	public void completionTime () {
		int completionTime = (baseWorkingTime()+ additionalWorkingTime()) * RoundUp(lapelWidth * 1.75) ;
	}

}
