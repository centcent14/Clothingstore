package QueensMan;

import java.util.Random;

public class Dress extends Clothes {
	Random rand = new Random();
	public Dress(int completionTime) {
		
		
	}
	public void additionalWorkingTime () {
		int additionalWorkingTime = rand.nextInt(10);
	}
	public void completionTime () {
		int completionTime = (baseWorkingTime()+ additionalWorkingTime()) * RoundUp(lapelWidth * 2.25) ;
	}
}
